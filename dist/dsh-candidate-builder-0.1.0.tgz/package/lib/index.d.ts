/**
 * In-process candidate builder subagent backend: registers a {@link SubagentProvider} on
 * `ctx.subagents` that runs each child as a fresh in-process child agent
 * hard-confined to ONE directory.
 *
 * Confinement layers, strongest first:
 * 1. The child session's `cwd` IS the confined directory and its sandbox mode
 *    is pinned to `workspace-write` — the file sandbox's write boundary.
 * 2. A monotonic tool guard registered in the child's scope validates the path
 *    argument of `read`/`write`/`edit`/`glob`/`grep`/`read_image` (absolute,
 *    relative, and `..` escapes) before the tool body runs.
 * 3. Skills stay available to every child (the catalog is instruction
 *    knowledge, never a path grant). The shell (pwsh/bash) is available unless
 *    the request sets `allowShell: false`; it runs under the sandbox of layer 1.
 *    Delegation tools (subagent/workflow/ralph), the `candidate-builder` tool
 *    itself, and the runtime tools (Cordis inspection, `plugin_manager`, the
 *    evolve tools) are never grantable, so the child cannot spawn unguarded
 *    grandchildren, install plugins, or change the search.
 * 4. The child's approval policy is pinned to `never`, so sandbox escalation
 *    (including `danger-full-access`) is impossible.
 *
 * The provider is one-shot only (no `prepareContinuable`), like the shipped
 * spawn backend but with its own child driver: the built-in in-process driver
 * always stamps the PARENT's cwd, while this backend must stamp the confined
 * directory.
 * @module dsh-candidate-builder
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ResolvedSubagentStartRequest } from '@deepseek-ai/dsh-subagent';
import type { ToolGuard } from '@deepseek-ai/dsh-tools';
import type { WorkerTimerOptions } from './timer.ts';
export declare const name = "subagent-candidate-builder";
export declare const inject: string[];
/** Config: the registry name to register the provider under. */
export interface Config {
    /** Provider name on `ctx.subagents` (default `candidate-builder`). */
    providerName: string;
}
export declare const Config: z<Config>;
/**
 * Confinement payload carried as an extra field on the start request. The
 * subagents service resolves `{ ...request, descriptor }`, so this field
 * reaches the provider verbatim; start children through the companion
 * `dsh-candidate-builder/tool` row, which always supplies it.
 */
export interface CandidateBuilderConfine {
    /** Absolute directory the child may read and write; everything else is denied. */
    readonly root: string;
    /** Whether the shell (pwsh/bash) is available to the child; only `false` removes it. */
    readonly allowShell: boolean;
    /** Extra tool names the delegating agent granted; never-grantable names are ignored. */
    readonly allowedTools?: readonly string[];
}
/** The start request a candidate-builder child carries. */
export interface CandidateBuilderStartRequest extends ResolvedSubagentStartRequest, WorkerTimerOptions {
    readonly confine?: CandidateBuilderConfine;
}
/**
 * The monotonic per-call guard installed in the CHILD's scope: it denies
 * forbidden tool names and any path argument that escapes the confined root.
 * Guards have no allow result, so nothing the child registers can overturn a
 * denial.
 * @param root - the absolute confined directory.
 * @param allowShell - whether the shell stays available (default true; only `false` removes it).
 * @returns the guard for `ctx.tools.guard`.
 */
export declare function makeGuard(root: string, allowShell?: boolean): ToolGuard;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map