/** Per-worker elapsed-time budget, armed by the first model attempt. */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { ContextFormed } from '@deepseek-ai/dsh-llm';
import type { SubagentResult } from '@deepseek-ai/dsh-subagent';
export interface WorkerTimerOptions {
    /** Omitted or zero disables the timer. */
    readonly timeoutSeconds?: number;
    /** Remaining seconds at which to warn; zero disables the warning. */
    readonly warningSeconds?: number;
}
export interface ResolvedWorkerTimer {
    readonly timeoutSeconds: number;
    readonly warningSeconds: number;
}
export interface WorkerTiming {
    readonly timeoutSeconds: number;
    readonly warningSeconds: number;
    readonly startedAt?: number;
    readonly deadline?: number;
    readonly elapsedSeconds: number;
    readonly warningQueued: boolean;
    readonly timedOut: boolean;
}
export interface TimedSubagentResult extends SubagentResult {
    readonly timing?: WorkerTiming;
}
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        'candidate-builder:timer': {
            kind: 'candidate-builder:timer';
        } & ContextFormed;
    }
}
export declare function resolveWorkerTimer(options: WorkerTimerOptions): ResolvedWorkerTimer | undefined;
export interface WorkerTimer {
    stop(): void;
    snapshot(): WorkerTiming;
}
/** Install before followup(), so even a fast first request cannot outrun the listener. */
export declare function installWorkerTimer(ctx: Context, child: Agent, options: ResolvedWorkerTimer, parentSignal: AbortSignal): WorkerTimer;
//# sourceMappingURL=timer.d.ts.map